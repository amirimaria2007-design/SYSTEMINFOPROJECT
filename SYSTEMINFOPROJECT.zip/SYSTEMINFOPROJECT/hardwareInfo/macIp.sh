#!/bin/bash
# MAC and IP Addresses Information Script
# NSCS Hardware Audit - MAC and IP Addresses

get_MAC_and_IP_addresses() {
    local type=$1 # Allows the main script to choose 'short' or 'full'
    
    if [[ "$type" == "short" ]]; then
        echo "---- MAC and IP Addresses Summary ----"
        IFACE=$(ip route | grep default | awk '{print $5}')
        IP=$(hostname -I | awk '{print $1}')
        MAC=$(cat /sys/class/net/$IFACE/address 2>/dev/null)
        printf "Interface : %s\n" "$IFACE"
        printf "IP        : %s\n" "$IP"
        printf "MAC       : %s\n" "$MAC"
    else
        echo "---- Full MAC and IP Report ----"
        printf "%-12s %-18s %-18s %-10s\n" "Interface" "IP Address" "MAC Address" "State"
        echo "------------------------------------------------------------------------"
        
        for iface_path in /sys/class/net/*; do
            iface_name=$(basename "$iface_path")
            [ "$iface_name" = "lo" ] && continue
            
            IP=$(ip -4 addr show "$iface_name" 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1)
            MAC=$(cat /sys/class/net/$iface_name/address 2>/dev/null)
            STATE=$(cat /sys/class/net/$iface_name/operstate 2>/dev/null)
            
            printf "%-12s %-18s %-18s %-10s\n" "$iface_name" "${IP:-N/A}" "${MAC:-N/A}" "${STATE:-N/A}"
        done
    fi   
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_MAC_and_IP_addresses "$1"
fi
