#!/bin/bash
# GPU Information Script
# NSCS Hardware Audit Module - GPU Component

get_gpu_info() {
    local type=$1 
    
    # Check if lspci command exists
    if ! command -v lspci &> /dev/null; then
        echo "ERROR: lspci command not found. Please install pciutils package."
        return 1
    fi
    
    if [[ "$type" == "short" ]]; then
        echo "--- GPU Summary ---"
        lspci | grep -i "vga\|3d\|display"
        echo
    else 
        echo "=================== GPU INFORMATION ==================="
        echo "===== Graphics Card Details ====="
        # -v provides more detail like kernel drivers and memory
        lspci -v | grep -A 12 -E "VGA|3D|Display"
        echo
        echo "===== Video Controller Kernel Modules ====="
        lsmod | grep -E "nvidia|amdgpu|i915|nouveau" || echo "No proprietary GPU modules loaded"
        echo
        echo "======================================================="
    fi
}

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_gpu_info "$1"
fi
