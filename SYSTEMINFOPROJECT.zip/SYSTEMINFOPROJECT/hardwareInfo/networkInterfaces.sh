#!/bin/bash

# Network Interfaces Information Script
# NSCS Hardware Audit Module - Network Interfaces

get_network_interfaces() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "---- Network Interfaces Summary ----"
        printf "%-10s %-10s %-18s %-6s\n" "Interface" "Type" "IPv4" "Status"
        echo "------------------------------------------"
        
        # Get all interfaces except loopback for main display
        for iface in $(ip -o link show | awk -F': ' '{print $2}'); do
            # Skip loopback for short report (optional)
            [[ "$iface" == "lo" ]] && continue
            
            # Determine type
            if [[ "$iface" =~ ^wlan ]] || [[ "$iface" =~ ^wlp ]] || [[ "$iface" =~ ^wl ]]; then
                TYPE="Wi-Fi"
            else
                TYPE="Ethernet"
            fi
            
            # Get status
            STATUS=$(ip -o link show "$iface" | awk '{print $9}')
            
            # Get IPv4
            IPV4=$(ip -4 -o addr show "$iface" | awk '{print $4}' | cut -d'/' -f1 | head -n1)
            [ -z "$IPV4" ] && IPV4="-"
            
            printf "%-10s %-10s %-18s %-6s\n" "$iface" "$TYPE" "$IPV4" "$STATUS"
        done
        
    else
        echo "===== FULL NETWORK INTERFACES REPORT ====="
        echo ""
        
        # Display each interface with detailed info
        for iface in $(ip -o link show | awk -F': ' '{print $2}'); do
            echo "=== Interface: $iface ==="
            
            # Determine type
            if [[ "$iface" == "lo" ]]; then
                TYPE="Loopback"
            elif [[ "$iface" =~ ^wlan ]] || [[ "$iface" =~ ^wlp ]] || [[ "$iface" =~ ^wl ]]; then
                TYPE="Wi-Fi"
            else
                TYPE="Ethernet"
            fi
            echo "  Type: $TYPE"
            
            # Get status
            STATUS=$(ip -o link show "$iface" | awk '{print $9}')
            echo "  Status: $STATUS"
            
            # Get MAC address
            MAC=$(ip -o link show "$iface" | awk '{print $17}')
            echo "  MAC Address: ${MAC:-N/A}"
            
            # Get MTU
            MTU=$(ip -o link show "$iface" | awk '{print $5}')
            echo "  MTU: ${MTU:-N/A}"
            
            # Get IPv4 addresses
            echo "  IPv4 Addresses:"
            ip -4 -o addr show "$iface" | awk '{print "    - " $4}' | cut -d'/' -f1 || echo "    - None"
            
            # Get IPv6 addresses
            echo "  IPv6 Addresses:"
            ip -6 -o addr show "$iface" | awk '{print "    - " $4}' | head -3 || echo "    - None"
            
            # Get Gateway for this interface (if default route)
            GATEWAY=$(ip route show default 2>/dev/null | grep "dev $iface" | awk '{print $3}')
            if [ -n "$GATEWAY" ]; then
                echo "  Gateway: $GATEWAY"
            fi
            
            # Get SSID for Wi-Fi
            if [[ "$TYPE" == "Wi-Fi" ]] && command -v iwgetid &> /dev/null; then
                SSID=$(iwgetid "$iface" -r 2>/dev/null)
                if [ -n "$SSID" ]; then
                    echo "  SSID: $SSID"
                fi
            fi
            
            # Get speed for ethernet
            if [[ "$TYPE" == "Ethernet" ]] && [ -d "/sys/class/net/$iface" ]; then
                SPEED=$(cat /sys/class/net/$iface/speed 2>/dev/null)
                if [ -n "$SPEED" ] && [ "$SPEED" != "-1" ]; then
                    echo "  Speed: ${SPEED}Mbps"
                fi
            fi
            
            echo ""
        done
        
        echo "=== Routing Table ==="
        ip route show
        echo ""
        
        echo "=== ARP Cache ==="
        ip neigh show | head -10
        echo ""
        
        echo "========================================================"
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function - FIXED: changed from get_cpu_info to get_network_interfaces
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_network_interfaces "$1"
fi
