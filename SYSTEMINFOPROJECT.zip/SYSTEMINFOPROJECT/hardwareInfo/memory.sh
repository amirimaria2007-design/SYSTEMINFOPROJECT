#!/bin/bash
# Memory information script
# NSCS Hardware Audit Module - memory

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Check if required commands exist
if ! command -v free &> /dev/null; then
    echo "ERROR: 'free' command not found. Please install procps package."
    exit 1
fi

get_memory_info() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        # --- SHORT REPORT ---
        echo "--- Memory Summary ---"
        free -h | grep "Mem:" | awk '{print "Total: " $2 ", Used: " $3 ", Free: " $4}'
        echo "Swap: $(free -h | grep "Swap:" | awk '{print "Total: " $2 ", Used: " $3}')"
        
    else
        # --- FULL REPORT ---
        echo "==================== MEMORY INFORMATION ==================="
        echo ""
        
        echo "====== Kernel Memory Info ======"
        cat /proc/meminfo | head -20
        echo ""
        
        echo "====== Total and Used Memory ======"
        free -h
        echo ""
        
        echo "====== Memory Statistics ======"
        if command -v vmstat &> /dev/null; then
            vmstat -s
        else
            echo "  vmstat not available (install sysstat package)"
        fi
        echo ""
        
        echo "====== Memory per Process (Top 10 by Memory Usage) ======"
        ps aux --sort=-%mem | head -11
        echo ""
        
        echo "====== Physical Memory Layout ======"
        # Check if running with sudo, if not show warning
        if [ "$EUID" -eq 0 ]; then
            if command -v lshw &> /dev/null; then
                lshw -class memory | grep -E "description|product|vendor|physical id|size" | head -20
            else
                echo "  lshw not available. Install with: sudo apt install lshw"
                dmidecode -t memory 2>/dev/null | grep -E "Size|Type|Speed" | head -10
            fi
        else
            echo "  Run with sudo for detailed physical memory information:"
            echo "  sudo $0 $type"
            echo ""
            echo "  Basic memory info:"
            dmidecode -t memory 2>/dev/null | grep -E "Size|Type|Speed" | head -5 || echo "  Cannot access memory hardware info"
        fi
        echo ""
        
        echo "====== Cache Information ======"
        cat /proc/meminfo | grep -i "cache" | head -10
        echo ""
        
        echo "====== Memory Pressure (if available) ======"
        if [ -f /proc/pressure/memory ]; then
            cat /proc/pressure/memory
        else
            echo "  Memory pressure stats not available (kernel >= 4.20 required)"
        fi
        echo ""
        
        echo "=========================================================="
    fi
}

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_memory_info "$1"
fi
