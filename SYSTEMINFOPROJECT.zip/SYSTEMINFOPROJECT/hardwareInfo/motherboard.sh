#!/bin/bash
# Motherboard Information Script
# NSCS Hardware Audit - Module Motherboard Info

get_motherboard_info() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "---- Motherboard Info Summary ----"
        BASE="/sys/devices/virtual/dmi/id"
        printf "Manufacturer : %s\n" "$(cat $BASE/board_vendor 2>/dev/null)"
        printf "Product      : %s\n" "$(cat $BASE/board_name 2>/dev/null)"
        printf "Version      : %s\n" "$(cat $BASE/board_version 2>/dev/null)"
        echo "-----------------------------------"
    else
        echo "---- Full Motherboard Report ----"
        BASE="/sys/devices/virtual/dmi/id"
        printf "%-20s : %s\n" "Manufacturer" "$(cat $BASE/board_vendor 2>/dev/null)"
        printf "%-20s : %s\n" "Product Name" "$(cat $BASE/board_name 2>/dev/null)"
        printf "%-20s : %s\n" "Version" "$(cat $BASE/board_version 2>/dev/null)"
        printf "%-20s : %s\n" "Serial Number" "$(cat $BASE/board_serial 2>/dev/null)"
        printf "%-20s : %s\n" "Asset Tag" "$(cat $BASE/board_asset_tag 2>/dev/null)"
        echo "-----------------------------------"
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_motherboard_info "$1"
fi
