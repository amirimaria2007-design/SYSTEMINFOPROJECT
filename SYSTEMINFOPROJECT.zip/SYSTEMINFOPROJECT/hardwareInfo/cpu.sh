#!/bin/bash
# CPU Information Script 
# NSCS Hardware Audit Module - CPU Component 

get_cpu_info() {
    local type=$1  # Allows the main script to choose 'short' or 'full'
    
    # Check if lscpu command exists
    if ! command -v lscpu &> /dev/null; then
        echo "ERROR: lscpu command not found. Please install util-linux package."
        return 1
    fi

    if [[ "$type" == "short" ]]; then
        # --- SHORT REPORT ---
        echo "--- CPU Summary ---"
        lscpu | grep "Model name"
        lscpu | grep "Architecture"
    else
        # --- FULL REPORT --- 
        echo "=================== CPU INFORMATION =================="
        echo "====== Basic CPU Info ====="
        lscpu
        echo
        echo "======= Vendor ID ======="
        lscpu | grep 'Vendor'
        echo
        echo "======= CPU Architecture ======="
        lscpu | grep 'Architecture'
        echo 
        echo "======= CPU Family ======="
        lscpu | grep -E "CPU family|Model|Stepping"
        echo
        echo "======= Number of CPU Physical Cores ======="
        lscpu | awk '/Core\(s\) per socket/ {cores=$4} /Socket\(s\)/ {sockets=$2} END {print cores * sockets}'
        echo
        echo "======= Number of Logical Cores ======="
        lscpu | grep "^CPU(s):"
        echo 
        echo "======= CPU Frequency ======="
        lscpu | grep 'GHz' | awk '{print $9}'
        echo
        echo "======= Caches ======="
        lscpu | grep -i 'cache'
        echo
        echo "======= CPU Flags ======="
        lscpu | grep -i 'flags'
        echo
        echo "======= Virtualization Features ======="
        lscpu | grep -i 'virtualization'
        echo
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_cpu_info "$1"
fi
