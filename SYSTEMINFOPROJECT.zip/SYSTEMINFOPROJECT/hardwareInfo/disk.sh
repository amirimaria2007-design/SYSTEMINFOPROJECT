#!/bin/bash
# Disk Information Script 
# NSCS Hardware Audit Module - Disk Information

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

type="$1"

# Check if required commands exist
if ! command -v lsblk &> /dev/null; then
    echo "ERROR: lsblk command not found. Please install util-linux package."
    exit 1
fi

if [[ "$type" == "short" ]]; then
    # --- SHORT REPORT ---
    echo "--- Disk Summary ---"
    echo "Disk Devices:"
    lsblk -d -o NAME,SIZE,MODEL | grep -v "loop" | tail -n +2 | while read line; do
        echo "  $line"
    done
    
    # Overall disk usage
    echo ""
    echo "Filesystem Usage:"
    df -h | grep -E "^/dev/" | head -3 | while read line; do
        echo "  $line"
    done
    
else 
    # --- FULL REPORT ---
    echo "====================== DISK INFORMATION ======================"
    echo "===== All Block Devices ====="
    lsblk 
    echo ""
    echo "===== Disk Details (Size & Model) ====="
    lsblk -d -o NAME,SIZE,TYPE,MODEL,VENDOR
    echo ""
    echo "===== File System Type ====="
    lsblk -f
    echo ""
    echo "===== Disk Usage (Human Readable) ====="
    df -hT
    echo ""
    echo "===== Inode Usage ====="
    df -i
    echo ""
    echo "===== Partition Information ====="
    lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL
    echo ""
    echo "===== Disk Type (SSD/HDD) ====="
    lsblk -d -o NAME,ROTA | tail -n +2 | while read disk rota; do
        if [ "$rota" -eq 0 ]; then
            echo "  /dev/$disk: SSD"
        else
            echo "  /dev/$disk: HDD"
        fi
    done
    echo ""
    echo "================================================================"
fi
