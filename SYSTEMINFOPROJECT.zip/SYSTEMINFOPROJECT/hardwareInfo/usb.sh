#!/bin/bash
# USB Devices Information Script
# NSCS Hardware Audit Module - USB Devices

get_usb_devices() {
    local type=$1 # Allows the main script to choose 'short' or 'full'
    
    if [[ "$type" == "short" ]]; then
        echo "---- USB Devices Summary ----"
        COUNT=$(find /sys/bus/usb/devices -name product 2>/dev/null | wc -l)
        printf "Connected USB devices : %s\n" "$COUNT"
        echo "-----------------------------"
    else
        echo "---- Full USB Devices Report ----"
        printf "%-20s %-50s\n" "Device ID" "Description"
        echo "--------------------------------------------------------------"
        
        for dev in /sys/bus/usb/devices/*; do
            [ -f "$dev/product" ] || continue
            PRODUCT=$(cat "$dev/product" 2>/dev/null)
            MANUFACTURER=$(cat "$dev/manufacturer" 2>/dev/null)
            
            # Create description from manufacturer and product
            if [ -n "$MANUFACTURER" ]; then
                DESCRIPTION="$MANUFACTURER $PRODUCT"
            else
                DESCRIPTION="$PRODUCT"
            fi
            
            printf "%-20s %-50s\n" "$(basename "$dev")" "$DESCRIPTION"
        done
        
        echo ""
        echo "Total USB Devices: $(find /sys/bus/usb/devices -name product 2>/dev/null | wc -l)"
        echo "--------------------------------------------------------------"
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_usb_devices "$1"
fi
