Linux System Audit & Monitoring System
NSCS Mini-Project - Part N°1 (2025/2026)

Developed by: MAHIOUT Meriem & AMIRI Maria

Course: Operating Systems 2

Instructor: Dr. BENTRAD Sassi

1. Project Overview

This system is an automated Linux-based auditing solution designed to collect hardware and software configurations for Cybersecurity risk assessment and incident response. It automates the generation of technical reports and supports remote monitoring via SSH.

2. Key Features

    Hardware Audit: Detailed collection of CPU, RAM, Disk, Network (IP/MAC), Motherboard, and USB info.

Software Audit: Inventory of OS version, Kernel, running services, open ports, and installed packages.

Dual Reporting: Generates both Short (Summary) and Full (Detailed) reports in structured formats.

Automated Transmission: Reports are automatically saved to /var/log/sys_audit/ and sent via email (SMTP).

Scheduled Execution: Built-in support for automation via cron jobs.

Remote Monitoring: Capability to centralize reports from multiple machines via SSH.

3. Installation & Prerequisites
Requirements

    OS: Ubuntu, Kali, or any Debian-based Linux distribution.

Language: Bash / Shell Script.

Tools: Standard Linux utilities (e.g., lscpu, free, df, ip, dpkg, ss).

Mail Client: msmtp for email functionality.

Setup

clone/Extract the project:

    tar -xvf audit_system.tar.gz
    cd audit_system

Ensure script permissions:

    chmod +x audit_main.sh

Create log directory:

    sudo mkdir -p /var/log/sys_audit/
    sudo chown $USER:$USER /var/log/sys_audit/

4. Configuration

Before running the script, configure your environment variables in the configuration file:

    Email Setup: Provide the recipient email and SMTP settings in the script headers or searate config file.

Report Type: Toggle between SHORT or FULL report generation.

Remote Access: Configure SSH keys for passwordless remote monitoring.

5. Usage

Manual Execution

To run a manual audit immediately:

./audit_main.sh --full   # Generates full report
./audit_main.sh --short  # Generates summary report

Automation (Cron)

To schedule the audit to run daily at 04:00 PM:

    Open crontab: crontab -e

    Add the following line:
    Bash

    00 04 * * * /path/to/audit_main.sh --full

6. Security Considerations

    Log Integrity: The system uses sha256sum to verify the integrity of generated logs and detect unauthorized changes.

    Secure Remote Access: All remote monitoring is conducted over encrypted SSH tunnels.

    Error Handling: The script includes modular error checking to prevent execution failure during system resource spikes.
    