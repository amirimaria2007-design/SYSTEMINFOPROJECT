#!/bin/bash

# ==================== EMAIL SCRIPT ====================
# NSCS Cybersecurity Project - Email Transmission Module

# ==================== COLORS ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# ==================== CONFIGURATION ====================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORT_DIR="/var/log/sys_audit"
LOCAL_REPORT_DIR="${SCRIPT_DIR}/reports"
REMOTE_REPORT_DIR="${SCRIPT_DIR}/remote_reports"

# Your email (change this to your Gmail)
FROM_EMAIL="amirimaria2007@gmail.com"

# ==================== FUNCTIONS ====================

show_banner() {
    echo ""
    echo -e "${CYAN}========================================${NC}"
    echo -e "${CYAN}     NSCS - EMAIL REPORT MODULE${NC}"
    echo -e "${CYAN}========================================${NC}"
    echo ""
	
}

# Find all reports
find_reports() {
    local reports=()
    for dir in "$REPORT_DIR" "$LOCAL_REPORT_DIR" "$REMOTE_REPORT_DIR"; do
        if [ -d "$dir" ]; then
            while IFS= read -r file; do
                if [ -f "$file" ]; then
                    reports+=("$file")
                fi
            done < <(find "$dir" -maxdepth 1 -name "*.txt" 2>/dev/null | sort -r)
        fi
    done
    printf '%s\n' "${reports[@]}"
}

# List available reports
list_reports() {
    local reports=($(find_reports))
    
    if [ ${#reports[@]} -eq 0 ]; then
        echo -e "${RED}No reports found! Run ./main.sh first${NC}"
        return 1
    fi
    
    echo ""
    echo -e "${CYAN}========================================${NC}"
    echo -e "${YELLOW}         AVAILABLE REPORTS${NC}"
    echo -e "${CYAN}========================================${NC}"
    echo ""
    
    local count=1
    for report in "${reports[@]}"; do
        local filename=$(basename "$report")
        local size=$(du -h "$report" 2>/dev/null | cut -f1)
        echo -e "  ${GREEN}$count${NC}) ${CYAN}$filename${NC} (${YELLOW}$size${NC})"
        ((count++))
    done
    echo ""
    
    return 0
}

# Select a report
select_report() {
    local reports=($(find_reports))
    
    if [ ${#reports[@]} -eq 0 ]; then
        return 1
    fi
    
    list_reports
    echo -ne "${YELLOW}Select report number [1-${#reports[@]}]: ${NC}"
    read num
    
    if [[ "$num" =~ ^[0-9]+$ ]] && [ "$num" -ge 1 ] && [ "$num" -le ${#reports[@]} ]; then
        echo "${reports[$((num-1))]}"
        return 0
    else
        echo -e "${RED}Invalid selection${NC}"
        return 1
    fi
}

# Send email using msmtp
send_email() {
    local recipient="$1"
    local report_file="$2"
    
    if [ ! -f "$report_file" ]; then
        echo -e "${RED}✗ Report not found: $report_file${NC}"
        return 1
    fi
    
    local subject="System Audit Report - $(hostname) - $(date +%Y-%m-%d_%H:%M:%S)"
    local filename=$(basename "$report_file")
    
    echo ""
    echo -e "${BLUE}From: $FROM_EMAIL${NC}"
    echo -e "${BLUE}To: $recipient${NC}"
    echo -e "${BLUE}Subject: $subject${NC}"
    echo -e "${BLUE}Attachment: $filename${NC}"
    echo ""
    echo -e "${YELLOW}Sending...${NC}"
    
    # Send using msmtp
    {
        echo "To: $recipient"
        echo "From: $FROM_EMAIL"
        echo "Subject: $subject"
        echo "Content-Type: text/plain; charset=utf-8"
        echo ""
        echo "System Audit Report from $(hostname)"
        echo "Generated on: $(date)"
        echo "Report file: $filename"
        echo ""
        echo "========================================="
        echo ""
        cat "$report_file"
    } | msmtp "$recipient"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Email sent successfully to $recipient${NC}"
        return 0
    else
        echo -e "${RED}✗ Failed to send email${NC}"
        echo -e "${YELLOW}Check: cat ~/.msmtprc${NC}"
        return 1
    fi
}

# Send latest report
send_latest() {
    local recipient="$1"
    local reports=($(find_reports))
    
    if [ ${#reports[@]} -eq 0 ]; then
        echo -e "${RED}✗ No reports found${NC}"
        echo -e "${YELLOW}Run ./main.sh both short first${NC}"
        return 1
    fi
    
    local latest="${reports[0]}"
    echo -e "${GREEN}✓ Latest report: $(basename "$latest")${NC}"
    send_email "$recipient" "$latest"
}

# ==================== MAIN ====================
main() {
    # Check if msmtp is installed
    if ! command -v msmtp &>/dev/null; then
        echo -e "${RED}✗ msmtp not installed${NC}"
        echo -e "${YELLOW}Install with: sudo apt install msmtp msmtp-mta${NC}"
        exit 1
    fi
    
    # Check if msmtp is configured
    if [ ! -f ~/.msmtprc ]; then
        echo -e "${RED}✗ msmtp not configured${NC}"
        echo -e "${YELLOW}Create ~/.msmtprc with your Gmail settings${NC}"
        exit 1
    fi
    
    if [ $# -eq 1 ]; then
        # Command line: ./email.sh recipient@example.com
        send_latest "$1"
    else
        # Interactive mode
        show_banner
        echo -e "${YELLOW}Enter recipient email address:${NC}"
        echo -ne "${CYAN}> ${NC}"
        read recipient
        
        if [ -z "$recipient" ]; then
            echo -e "${RED}No email entered${NC}"
            exit 1
        fi
        
        send_latest "$recipient"
    fi
}

main "$@"
