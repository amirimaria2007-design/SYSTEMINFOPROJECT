#!/bin/bash
# NSCS Software Audit Module - Open Ports Component

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

get_ports_info() {
    local type=$1

    if [[ "$type" == "short" ]]; then
        # --- SHORT REPORT ---
        echo "----------- PORTS SUMMARY ---------------"
        
        # Try ss first (newer)
        if command -v ss &> /dev/null; then
            listening_ports=$(ss -tuln | grep -c LISTEN)
            echo "  Listening ports: $listening_ports"
            echo ""
            echo "  Common listening ports:"
            ss -tuln | grep LISTEN | awk '{print "    " $5}' | cut -d':' -f2 | sort -n | uniq -c | head -5
        # Try netstat as fallback
        elif command -v netstat &> /dev/null; then
            listening_ports=$(netstat -tuln | grep -c LISTEN)
            echo "  Listening ports: $listening_ports"
            echo ""
            echo "  Common listening ports:"
            netstat -tuln | grep LISTEN | awk '{print "    " $4}' | cut -d':' -f2 | sort -n | uniq -c | head -5
        else
            echo "  No port checking tools available (install net-tools or iproute2)"
        fi
        
    else
        # --- FULL REPORT ---
        echo "====== OPEN PORTS INFORMATION ======"
        echo ""
        
        # Using ss (modern, preferred)
        if command -v ss &> /dev/null; then
            echo "====== TCP Listening Ports ======"
            echo "----------------------------------------"
            ss -tlnp 2>/dev/null | head -30 || ss -tln | head -30
            echo ""
            
            echo "====== UDP Listening Ports ======"
            echo "----------------------------------------"
            ss -ulnp 2>/dev/null | head -20 || ss -uln | head -20
            echo ""
            
            echo "====== All Listening Ports (with processes) ======"
            echo "----------------------------------------"
            ss -tulpn 2>/dev/null | head -30 || ss -tuln | head -30
            
        # Using netstat (older, fallback)
        elif command -v netstat &> /dev/null; then
            echo "====== TCP Listening Ports ======"
            echo "----------------------------------------"
            netstat -tlnp 2>/dev/null | grep LISTEN | head -30 || netstat -tln | grep LISTEN | head -30
            echo ""
            
            echo "====== UDP Listening Ports ======"
            echo "----------------------------------------"
            netstat -ulnp 2>/dev/null | head -20 || netstat -uln | head -20
            echo ""
            
            echo "====== All Listening Ports ======"
            echo "----------------------------------------"
            netstat -tulnp 2>/dev/null | grep LISTEN | head -30 || netstat -tuln | grep LISTEN | head -30
            
        # Using lsof if available
        elif command -v lsof &> /dev/null && [ "$EUID" -eq 0 ]; then
            echo "====== Processes with Open Ports ======"
            echo "----------------------------------------"
            lsof -i -P -n | head -30
            
        else
            echo "No port checking tools available."
            echo "Install with: sudo apt-get install net-tools iproute2 lsof"
        fi
        
        echo ""
        echo "====== Port Summary ======"
        if command -v ss &> /dev/null; then
            echo "  Total listening ports: $(ss -tuln | grep -c LISTEN)"
            echo "  TCP ports: $(ss -tln | grep -c LISTEN)"
            echo "  UDP ports: $(ss -uln | grep -c LISTEN)"
        elif command -v netstat &> /dev/null; then
            echo "  Total listening ports: $(netstat -tuln | grep -c LISTEN)"
            echo "  TCP ports: $(netstat -tln | grep -c LISTEN)"
            echo "  UDP ports: $(netstat -uln | grep -c LISTEN)"
        fi
        echo ""
        
        echo "=========================================================="
    fi
}

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_ports_info "$1"
fi
