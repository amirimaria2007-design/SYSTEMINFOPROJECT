#!/bin/bash
# NSCS Software Audit Module - Processes Component

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

get_processes_info() {
    local type=$1

    if [[ "$type" == "short" ]]; then
        # --- SHORT REPORT ---
        echo "----------- PROCESSES SUMMARY ---------------"
        
        total_processes=$(ps aux | wc -l)
        echo "  Total processes: $total_processes"
        echo ""
        echo "  Top 5 CPU consuming processes:"
        ps aux --sort=-%cpu | head -6 | tail -5 | awk '{print "    " $11 " (" $3 "% CPU)"}'
        echo ""
        echo "  Top 5 Memory consuming processes:"
        ps aux --sort=-%mem | head -6 | tail -5 | awk '{print "    " $11 " (" $4 "% MEM)"}'
        
    else
        # --- FULL REPORT ---
        echo "====== PROCESSES INFORMATION ======"
        echo ""
        
        echo "====== Process Statistics ======"
        echo "Total processes: $(ps aux | wc -l)"
        echo "User processes: $(ps aux | grep -c "^$USER")"
        echo "Root processes: $(ps aux | grep -c "^root")"
        echo ""
        
        echo "====== Top 20 Processes by CPU Usage ======"
        echo "----------------------------------------"
        ps aux --sort=-%cpu | head -20
        echo ""
        
        echo "====== Top 20 Processes by Memory Usage ======"
        echo "----------------------------------------"
        ps aux --sort=-%mem | head -20
        echo ""
        
        echo "====== Process Tree (First 20 lines) ======"
        echo "----------------------------------------"
        pstree | head -20
        echo ""
        
        echo "====== Zombie Processes ======"
        zombies=$(ps aux | grep -c "Z")
        if [ $zombies -gt 0 ]; then
            echo "  Found $zombies zombie processes:"
            ps aux | grep "Z" | grep -v grep
        else
            echo "  No zombie processes found"
        fi
        echo ""
        
        echo "====== Processes by User ======"
        echo "----------------------------------------"
        ps aux | awk '{print $1}' | sort | uniq -c | sort -nr | head -10
        echo ""
        
        echo "=========================================================="
    fi
}

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_processes_info "$1"
fi
get_processes_info "$1"
