#!/bin/bash

# Installed Packages Information Script
# NSCS Software Audit - Installed Packages

get_installed_packages() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "---- Installed Packages Summary ----"
        
        # Count total installed packages (works on Debian/Ubuntu/Kali)
        if command -v dpkg &>/dev/null; then
            PKG_COUNT=$(dpkg -l 2>/dev/null | grep -c '^ii')
            PKG_MANAGER="dpkg (Debian/Ubuntu)"
        elif command -v rpm &>/dev/null; then
            PKG_COUNT=$(rpm -qa 2>/dev/null | wc -l)
            PKG_MANAGER="rpm (RedHat/CentOS)"
        elif command -v pacman &>/dev/null; then
            PKG_COUNT=$(pacman -Q 2>/dev/null | wc -l)
            PKG_MANAGER="pacman (Arch)"
        else
            PKG_COUNT="Unknown"
            PKG_MANAGER="Unknown"
        fi
        
        printf "Package Manager : %s\n" "$PKG_MANAGER"
        printf "Total Packages  : %s\n" "$PKG_COUNT"
        echo "-------------------------------------"
        
    else
        echo "---- Full Installed Packages Report ----"
        printf "%-60s %-20s\n" "Package" "Version"
        echo "------------------------------------------------------------------------"
        
        # List all installed packages with versions
        if command -v dpkg &>/dev/null; then
            dpkg -l 2>/dev/null | awk '/^ii/ {printf "%-60s %-20s\n", $2, $3}'
        elif command -v rpm &>/dev/null; then
            rpm -qa --queryformat "%-60s %-20s\n" 2>/dev/null
        elif command -v pacman &>/dev/null; then
            pacman -Q 2>/dev/null | awk '{printf "%-60s %-20s\n", $1, $2}'
        else
            echo "Error: No supported package manager found"
            echo "Supported: dpkg, rpm, pacman"
        fi
        
        echo "-----------------------------------------"
    fi
}

# Check if arguments are provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    echo "Example: $0 short"
    echo "         $0 full"
    exit 1
fi

# Validate argument
if [[ "$1" != "short" && "$1" != "full" ]]; then
    echo "Error: Invalid argument. Please use 'short' or 'full'"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_installed_packages "$1"
fi
get_installed_packages "$1"
