#!/bin/bash
# Kernel Information Script

# NSCS Software Audit Module - Kernel Component

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

get_kernel_info() {
    local type=$1
    
    # ----- SHORT REPORT ---
    if [[ "$type" == "short" ]]; then
        echo "===== KERNEL SUMMARY ====="
        echo "  Kernel release: $(uname --kernel-release)"
        echo "  Kernel name: $(uname -s)"
        echo "  Kernel version: $(uname -v)"
        
    else
        # ------ FULL REPORT ----
        echo "====================== KERNEL INFORMATION ======================"
        echo ""
        
        echo "===== Basic Kernel Information ====="
        echo "  Kernel release: $(uname --kernel-release)"
        echo "  Kernel name: $(uname -s)"
        echo "  Kernel version: $(uname -v)"
        echo "  Machine: $(uname -m)"
        echo "  Node Name: $(uname -n)"
        echo "  Operating System: $(uname -o)"
        echo ""
        
        echo "===== Detailed Kernel Information ====="
        uname -a
        echo ""
        
        echo "===== Kernel Modules (first 20) ====="
        lsmod | head -20
        echo ""
        
        echo "===== Kernel Parameters (first 20) ====="
        if command -v sysctl &>/dev/null; then
            sysctl -a 2>/dev/null | head -20
        else
            echo "  sysctl command not available"
        fi
        echo ""
        
        echo "===== Kernel Version Details ====="
        if [ -f /proc/version ]; then
            cat /proc/version
        else
            echo "  /proc/version not found"
        fi
        echo ""
        
        echo "===== Kernel Command Line ====="
        if [ -f /proc/cmdline ]; then
            cat /proc/cmdline
            echo ""
        else
            echo "  /proc/cmdline not found"
        fi
        echo ""
        
        echo "===== Kernel Uptime ====="
        uptime
        echo ""
        
        echo "================================================================"
    fi
}

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_kernel_info "$1"
fi
