#!/bin/bash
# Logged in Users Information Script
# NSCS Software Audit - Logged in Users

get_logged_in_users() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "---- Logged in Users Summary ----"
        USERS=$(who | awk '{print $1}' | sort | uniq | tr '\n' ' ')
        echo "$USERS"
        echo "----------------------------------"
    else
        echo "---- Full Logged in Users Report ----"
        printf "%-15s %-15s %-20s\n" "Username" "TTY" "Login Time"
        echo "------------------------------------------------"
        who | while read user tty date time rest; do
            printf "%-15s %-15s %-20s\n" "$user" "$tty" "$date $time"
        done
        echo ""
        echo "Total logged in users: $(who | wc -l)"
        echo "------------------------------------------------"
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_logged_in_users "$1"
fi
