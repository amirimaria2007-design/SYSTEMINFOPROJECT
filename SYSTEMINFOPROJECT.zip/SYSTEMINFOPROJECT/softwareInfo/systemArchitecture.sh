#!/bin/bash
# NSCS Software Audit Module - System Architecture Component

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

get_system_info() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "--- SYSTEM ARCHITECTURE SUMMARY ---"
        echo "  Architecture: $(uname -m)"
        echo "  Processor: $(uname -p)"
        echo "  Hardware Platform: $(uname -i)"
        echo "  32/64-bit: $(getconf LONG_BIT)-bit"
        
    else
        # ----- FULL REPORT ---
        echo "==================== SYSTEM ARCHITECTURE INFORMATION ===================="
        echo ""
        
        echo "===== CPU Architecture ====="
        echo "  Machine hardware Name: $(uname -m)"
        echo "  Processor type: $(uname -p)"
        echo "  Hardware Platform: $(uname -i)"
        echo "  Kernel Architecture: $(uname -a | awk '{print $NF}')"
        echo ""
        
        echo "===== Bit System ====="
        echo "  Long bit: $(getconf LONG_BIT)-bit"
        echo "  Word size: $(getconf WORD_BIT)-bit"
        echo ""
        
        echo "===== CPU Information ====="
        if command -v lscpu &>/dev/null; then
            lscpu | grep -E "Architecture|CPU op-mode|Byte Order|CPU\(s\)|Model name"
        else
            echo "  lscpu not available"
        fi
        echo ""
        
        echo "===== Architecture-specific Info ====="
        if [[ "$(uname -m)" == "x86_64" ]]; then
            echo "  x86_64 Architecture"
            echo "  CPU Features:"
            grep -m1 flags /proc/cpuinfo 2>/dev/null | cut -d':' -f2- | tr ' ' '\n' | grep -E "lm|rm|sm|cmov|nx|pae" | head -10
        elif [[ "$(uname -m)" == "aarch64" ]]; then
            echo "  ARM 64-bit Architecture"
        elif [[ "$(uname -m)" == "armv7l" ]]; then
            echo "  ARM 32-bit Architecture"
        else
            echo "  Unknown Architecture: $(uname -m)"
        fi
        echo ""
        
        echo "===== Library Architecture ====="
        if command -v ldconfig &>/dev/null; then
            echo "  Default library path:"
            ldconfig -p 2>/dev/null | head -5
        else
            echo "  Cannot access ldconfig"
        fi
        echo ""
        
        echo "===== Endianness ====="
        if echo "I" | od -to2 | head -1 | grep -q "000000"; then
            echo "  Endianness: Little Endian"
        else
            echo "  Endianness: Big Endian"
        fi
        echo ""
        
        echo "================================================================"
    fi
}

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_system_info "$1"
fi
get_system_info "$1"
