#!/bin/bash
# NSCS Software Audit Module - OS Component

# Usage check
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi
get_os_info(){
    local type=$1
        # Check if required commands exist

    if [[ "$type" == "short" ]]; then
       #----SHORT REPORT---
       echo "-----------OPERATING SYSTEM SUMMARY---------------"
       
        echo "  Kernel: $(uname -r)"
        echo "  Architecture: $(uname -m)"
        echo "  Hostname: $(hostname)"
    else
        echo "======OPERATING SYSTEM INFORMATION===="
        echo ""
        echo "====== OS Release Information ======"
        if command -v lsb_release &> /dev/null; then
            echo "LSB Release (most accurate):"
            lsb_release -a 2>/dev/null
        else
            echo "LSB release not available"
        fi
        echo ""
        echo "====== OS Release File Contents ======"
        if [ -f /etc/os-release ]; then
            cat /etc/os-release
        elif [ -f /etc/redhat-release ]; then
            cat /etc/redhat-release
        elif [ -f /etc/debian_version ]; then
            echo "Debian version: $(cat /etc/debian_version)"
        fi
        echo ""
        echo "====== Kernel Information ======"
        uname -a
        echo ""
        echo "====== System Information ======"
        echo "Hostname: $(hostname)"
        echo "Domain: $(hostname -d 2>/dev/null || echo 'Not configured')"
        echo "NIS Domain: $(domainname 2>/dev/null || echo 'Not configured')"
        echo ""
        echo "====== Date & Time ======"
        echo "System Date: $(date)"
        echo "Timezone: $(cat /etc/timezone 2>/dev/null || echo 'Unknown')"
        echo "Uptime: $(uptime)"
        echo ""
        echo "====== System Architecture ======"
        echo "Machine: $(uname -m)"
        echo "Processor: $(uname -p)"
        echo "Hardware Platform: $(uname -i)"
        echo ""
        echo "====== OS Version Details ======"
        if [ -f /etc/issue ]; then
            echo "Issue file: $(cat /etc/issue)"
        fi
        echo ""
        
        echo "=========================================================="

    fi
}
# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_os_info "$1"
fi
get_os_info "$1"
