#!/bin/bash
# Running Services Information Script
# NSCS Software Audit - Running Services

get_running_services() {
    local type=$1
    
    if [[ "$type" == "short" ]]; then
        echo "---- Running Services Summary ----"
        ACTIVE_COUNT=$(systemctl list-units --type=service --state=running 2>/dev/null | grep -c "\.service")
        echo "Active services: $ACTIVE_COUNT"
        echo "-----------------------------------"
    else
        echo "---- Full Running Services Report ----"
        printf "%-40s %-10s\n" "Service" "State"
        echo "--------------------------------------------------"
        systemctl list-units --type=service --state=running 2>/dev/null | \
        awk 'NR>1 && $1 ~ /\.service/ {printf "%-40s %-10s\n", $1, $3}'
        echo "--------------------------------------------------"
    fi
}

# Usage check (number of passed arguments equals 0)
if [ $# -eq 0 ]; then
    echo "Usage: $0 [short|full]"
    exit 1
fi

# Call the function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    get_running_services "$1"
fi
get_running_services "$1"
