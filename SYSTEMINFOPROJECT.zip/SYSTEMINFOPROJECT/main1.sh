#!/bin/bash

# ==================== CONFIGURATION ====================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HARDWARE_DIR="${SCRIPT_DIR}/hardwareInfo"
SOFTWARE_DIR="${SCRIPT_DIR}/softwareInfo"
REPORT_DIR="${SCRIPT_DIR}/reports"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
HOSTNAME=$(hostname)

mkdir -p "$REPORT_DIR"

# Email configuration
FROM_EMAIL="amirimaria2007@gmail.com"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m'

# Default values
AUDIT_SCOPE=""
REPORT_TYPE=""
REPORT_FORMAT="txt"

# Clear screen
clear

# Display Banner
echo ""
echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
echo -e "${CYAN}${BOLD}║     ${YELLOW}NSCS - SYSTEM AUDIT & MONITORING SOLUTION${CYAN}                  ║${NC}"
echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
echo -e "${CYAN}${BOLD}║     ${GREEN}Linux Automated Audit Tool${CYAN}                                   ║${NC}"
echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Display System Information
echo -e "${GREEN}${BOLD}System Information:${NC}"
echo -e "  ${WHITE}Hostname    : ${GREEN}$HOSTNAME${NC}"
echo -e "  ${WHITE}User        : ${GREEN}$USER${NC}"
echo -e "  ${WHITE}Date        : ${GREEN}$(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo -e "  ${WHITE}Uptime      : ${GREEN}$(uptime -p | sed 's/up //')${NC}"
echo ""

# ==================== MENU 1: CHOOSE AUDIT SCOPE ====================
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}${BOLD}                    STEP 1: SELECT AUDIT SCOPE${NC}"
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}1${NC}) ${CYAN}Hardware Audit Only${NC}"
echo -e "  ${GREEN}2${NC}) ${CYAN}Software Audit Only${NC}"
echo -e "  ${GREEN}3${NC}) ${CYAN}Complete Audit (Hardware + Software)${NC}"
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""

while true; do
    echo -ne "${YELLOW}${BOLD}Enter your choice [1-3]: ${NC}"
    read scope_choice
    echo ""
    
    case $scope_choice in
        1)
            AUDIT_SCOPE="hardware"
            echo -e "${GREEN}✓ You selected: Hardware Audit Only${NC}"
            break
            ;;
        2)
            AUDIT_SCOPE="software"
            echo -e "${GREEN}✓ You selected: Software Audit Only${NC}"
            break
            ;;
        3)
            AUDIT_SCOPE="both"
            echo -e "${GREEN}✓ You selected: Complete Audit (Hardware + Software)${NC}"
            break
            ;;
        *)
            echo -e "${RED}✗ Invalid choice. Please enter 1, 2, or 3.${NC}"
            echo ""
            ;;
    esac
done

echo ""
sleep 1

# ==================== MENU 2: CHOOSE REPORT TYPE ====================
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}${BOLD}                    STEP 2: SELECT REPORT TYPE${NC}"
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}1${NC}) ${CYAN}Short Report (Summary)${NC}"
echo -e "  ${GREEN}2${NC}) ${CYAN}Full Report (Detailed)${NC}"
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""

while true; do
    echo -ne "${YELLOW}${BOLD}Enter your choice [1-2]: ${NC}"
    read report_choice
    echo ""
    
    case $report_choice in
        1)
            REPORT_TYPE="short"
            echo -e "${GREEN}✓ You selected: Short Report (Summary)${NC}"
            break
            ;;
        2)
            REPORT_TYPE="full"
            echo -e "${GREEN}✓ You selected: Full Report (Detailed)${NC}"
            break
            ;;
        *)
            echo -e "${RED}✗ Invalid choice. Please enter 1 or 2.${NC}"
            echo ""
            ;;
    esac
done

echo ""
sleep 1

# ==================== MENU 3: CHOOSE OUTPUT FORMAT ====================
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}${BOLD}                    STEP 3: SELECT OUTPUT FORMAT${NC}"
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}1${NC}) ${CYAN}TXT - Plain Text${NC}"
echo -e "  ${GREEN}2${NC}) ${CYAN}HTML - Web Page${NC}"
echo -e "  ${GREEN}3${NC}) ${CYAN}JSON - Machine Readable${NC}"
echo -e "  ${GREEN}4${NC}) ${CYAN}PDF - Document (requires wkhtmltopdf)${NC}"
echo ""
echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""

while true; do
    echo -ne "${YELLOW}${BOLD}Enter your choice [1-4]: ${NC}"
    read format_choice
    echo ""
    
    case $format_choice in
        1)
            REPORT_FORMAT="txt"
            echo -e "${GREEN}✓ You selected: TXT Format${NC}"
            break
            ;;
        2)
            REPORT_FORMAT="html"
            echo -e "${GREEN}✓ You selected: HTML Format${NC}"
            break
            ;;
        3)
            REPORT_FORMAT="json"
            echo -e "${GREEN}✓ You selected: JSON Format${NC}"
            break
            ;;
        4)
            REPORT_FORMAT="pdf"
            echo -e "${GREEN}✓ You selected: PDF Format${NC}"
            if ! command -v wkhtmltopdf &>/dev/null; then
                echo -e "${YELLOW}⚠ wkhtmltopdf not installed. Install with: sudo apt install wkhtmltopdf${NC}"
            fi
            break
            ;;
        *)
            echo -e "${RED}✗ Invalid choice. Please enter 1, 2, 3, or 4.${NC}"
            echo ""
            ;;
    esac
done

echo ""
echo -e "${YELLOW}Starting audit in 2 seconds...${NC}"
sleep 2

# ==================== FUNCTIONS ====================

# Run hardware audit
run_hardware() {
    echo ""
    echo -e "${PURPLE}${BOLD}================== HARDWARE INFORMATION ==================${NC}"
    echo ""
    
    for module in cpu.sh memory.sh disk.sh gpu.sh motherboard.sh networkinterfaces.sh macp.sh usb.sh; do
        module_path="${HARDWARE_DIR}/${module}"
        if [ -f "$module_path" ]; then
            echo -e "${BLUE}--- ${module%.sh^^} ---${NC}"
            bash "$module_path" "$REPORT_TYPE"
            echo ""
        else
            echo -e "${RED}--- ${module%.sh^^} --- Module not found${NC}"
            echo ""
        fi
    done
}

# Run software audit
run_software() {
    echo ""
    echo -e "${PURPLE}${BOLD}================== SOFTWARE INFORMATION ==================${NC}"
    echo ""
    
    for module in os.sh kernel.sh loggedInUsers.sh openPorts.sh processes.sh runningServices.sh systemArchitecture.sh installedPackages.sh; do
        module_path="${SOFTWARE_DIR}/${module}"
        if [ -f "$module_path" ]; then
            echo -e "${BLUE}--- ${module%.sh^^} ---${NC}"
            bash "$module_path" "$REPORT_TYPE"
            echo ""
        else
            echo -e "${RED}--- ${module%.sh^^} --- Module not found${NC}"
            echo ""
        fi
    done
}

# Generate HTML report
generate_html() {
    local txt_file="$1"
    local html_file="${txt_file%.txt}.html"
    
    {
        echo "<!DOCTYPE html>"
        echo "<html>"
        echo "<head>"
        echo "  <title>System Audit Report - $HOSTNAME</title>"
        echo "  <style>"
        echo "    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }"
        echo "    .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 10px; }"
        echo "    h1 { color: #2c3e50; border-bottom: 3px solid #3498db; }"
        echo "    h2 { color: #34495e; background: #ecf0f1; padding: 10px; }"
        echo "    pre { background: #2c3e50; color: #ecf0f1; padding: 15px; border-radius: 5px; overflow-x: auto; }"
        echo "    .footer { font-size: 12px; color: #7f8c8d; text-align: center; margin-top: 30px; }"
        echo "  </style>"
        echo "</head>"
        echo "<body>"
        echo "<div class='container'>"
        echo "  <h1>🔍 NSCS System Audit Report</h1>"
        echo "  <p><strong>Hostname:</strong> $HOSTNAME</p>"
        echo "  <p><strong>Report Date:</strong> $(date)</p>"
        echo "  <p><strong>Report Type:</strong> ${REPORT_TYPE^^}</p>"
        echo "  <p><strong>Audit Scope:</strong> ${AUDIT_SCOPE^^}</p>"
        echo "  <hr>"
        
        sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g' "$txt_file" | while IFS= read -r line; do
            if [[ "$line" =~ ^===.*=== ]]; then
                echo "  <h2>$line</h2>"
            elif [[ "$line" =~ ^---.*--- ]]; then
                echo "  <h3>$line</h3>"
            else
                echo "  <pre>$line</pre>"
            fi
        done
        
        echo "  <div class='footer'>Generated by NSCS System Audit Tool on $(date)</div>"
        echo "</div>"
        echo "</body>"
        echo "</html>"
    } > "$html_file"
    
    echo "$html_file"
}

# Generate JSON report
generate_json() {
    local json_file="${REPORT_DIR}/audit_${HOSTNAME}_${AUDIT_SCOPE}_${REPORT_TYPE}_${TIMESTAMP}.json"
    
    {
        echo "{"
        echo "  \"report\": {"
        echo "    \"hostname\": \"$HOSTNAME\","
        echo "    \"date\": \"$(date)\","
        echo "    \"type\": \"${REPORT_TYPE^^}\","
        echo "    \"scope\": \"${AUDIT_SCOPE^^}\""
        echo "  },"
        echo "  \"hardware\": {"
        echo "    \"cpu\": \"$(lscpu | grep 'Model name' | cut -d':' -f2 | xargs)\","
        echo "    \"cores\": $(nproc),"
        echo "    \"memory_total\": \"$(free -h | grep Mem | awk '{print $2}')\","
        echo "    \"memory_used\": \"$(free -h | grep Mem | awk '{print $3}')\""
        echo "  },"
        echo "  \"software\": {"
        echo "    \"os\": \"$(lsb_release -ds 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2)\","
        echo "    \"kernel\": \"$(uname -r)\""
        echo "  }"
        echo "}"
    } > "$json_file"
    
    echo "$json_file"
}

# Generate PDF report
generate_pdf() {
    local html_file="$1"
    local pdf_file="${html_file%.html}.pdf"
    
    if command -v wkhtmltopdf &>/dev/null; then
        wkhtmltopdf "$html_file" "$pdf_file" 2>/dev/null
        echo "$pdf_file"
    else
        echo -e "${YELLOW}⚠ wkhtmltopdf not installed. Saving as HTML instead.${NC}"
        echo "$html_file"
    fi
}

# Send email using msmtp
send_email() {
    local recipient="$1"
    local report_file="$2"
    
    if [ ! -f "$report_file" ]; then
        echo -e "${RED}✗ Report not found: $report_file${NC}"
        return 1
    fi
    
    local subject="System Audit Report - $HOSTNAME - ${REPORT_TYPE^^} - $(date +%Y-%m-%d)"
    local filename=$(basename "$report_file")
    
    echo ""
    echo -e "${BLUE}From: $FROM_EMAIL${NC}"
    echo -e "${BLUE}To: $recipient${NC}"
    echo -e "${BLUE}Subject: $subject${NC}"
    echo ""
    echo -e "${YELLOW}Sending email...${NC}"
    
    # Check if msmtp is configured
    if ! command -v msmtp &>/dev/null; then
        echo -e "${RED}✗ msmtp not installed. Install with: sudo apt install msmtp msmtp-mta${NC}"
        return 1
    fi
    
    if [ ! -f ~/.msmtprc ]; then
        echo -e "${RED}✗ msmtp not configured. Create ~/.msmtprc with your Gmail settings${NC}"
        return 1
    fi
    
    # Send using msmtp
    {
        echo "To: $recipient"
        echo "From: $FROM_EMAIL"
        echo "Subject: $subject"
        echo "Content-Type: text/plain; charset=utf-8"
        echo ""
        echo "System Audit Report from $HOSTNAME"
        echo "Generated on: $(date)"
        echo "Report Type: ${REPORT_TYPE^^}"
        echo "Audit Scope: ${AUDIT_SCOPE^^}"
        echo "Report Format: ${REPORT_FORMAT^^}"
        echo ""
        echo "========================================="
        echo ""
        cat "$report_file"
    } | msmtp "$recipient"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Email sent successfully to $recipient${NC}"
        return 0
    else
        echo -e "${RED}✗ Failed to send email${NC}"
        return 1
    fi
}

# ==================== START AUDIT ====================

clear
echo -e "${CYAN}${BOLD}========================================================${NC}"
echo -e "${CYAN}${BOLD}              NSCS SYSTEM AUDIT TOOL${NC}"
echo -e "${CYAN}${BOLD}========================================================${NC}"
echo ""
echo -e "${GREEN}Audit Scope: ${YELLOW}${AUDIT_SCOPE^^}${NC}"
echo -e "${GREEN}Report Type: ${YELLOW}${REPORT_TYPE^^}${NC}"
echo -e "${GREEN}Output Format: ${YELLOW}${REPORT_FORMAT^^}${NC}"
echo ""

# Create base report file (TXT format first)
BASE_REPORT_FILE="${REPORT_DIR}/audit_${HOSTNAME}_${AUDIT_SCOPE}_${REPORT_TYPE}_${TIMESTAMP}.txt"

# Generate the audit content
{
    echo "========================================================"
    echo "              NSCS SYSTEM AUDIT REPORT"
    echo "========================================================"
    echo "Hostname: $HOSTNAME"
    echo "Report Date: $(date)"
    echo "Report Type: ${REPORT_TYPE^^}"
    echo "Audit Scope: ${AUDIT_SCOPE^^}"
    echo "Generated by: $USER"
    echo "========================================================"
    echo ""

    if [[ "$AUDIT_SCOPE" == "hardware" || "$AUDIT_SCOPE" == "both" ]]; then
        run_hardware
    fi

    if [[ "$AUDIT_SCOPE" == "software" || "$AUDIT_SCOPE" == "both" ]]; then
        if [[ "$AUDIT_SCOPE" == "both" ]]; then
            echo ""
            echo "========================================================"
            echo ""
        fi
        run_software
    fi

    echo ""
    echo "========================================================"
    echo "End of Report"
    echo "========================================================"
} | tee "$BASE_REPORT_FILE"

# Convert to selected format
FINAL_REPORT="$BASE_REPORT_FILE"
case $REPORT_FORMAT in
    html)
        FINAL_REPORT=$(generate_html "$BASE_REPORT_FILE")
        echo -e "${GREEN}✓ HTML report generated: $FINAL_REPORT${NC}"
        ;;
    json)
        FINAL_REPORT=$(generate_json)
        echo -e "${GREEN}✓ JSON report generated: $FINAL_REPORT${NC}"
        ;;
    pdf)
        HTML_FILE=$(generate_html "$BASE_REPORT_FILE")
        FINAL_REPORT=$(generate_pdf "$HTML_FILE")
        echo -e "${GREEN}✓ PDF report generated: $FINAL_REPORT${NC}"
        ;;
    txt)
        echo -e "${GREEN}✓ TXT report generated: $FINAL_REPORT${NC}"
        ;;
esac

echo ""
echo -e "${GREEN}${BOLD}========================================================${NC}"
echo -e "${GREEN}${BOLD}     AUDIT COMPLETED SUCCESSFULLY${NC}"
echo -e "${GREEN}${BOLD}========================================================${NC}"
echo ""
echo -e "${YELLOW}Report saved to: $FINAL_REPORT${NC}"

# ==================== ASK TO SEND EMAIL ====================
echo ""
echo -ne "${YELLOW}Do you want to send this report via email? (y/n): ${NC}"
read send_email_choice
if [[ "$send_email_choice" == "y" || "$send_email_choice" == "Y" ]]; then
    echo -ne "${YELLOW}Enter recipient email address: ${NC}"
    read recipient_email
    if [[ -n "$recipient_email" ]]; then
        send_email "$recipient_email" "$FINAL_REPORT"
    else
        echo -e "${RED}No email entered. Skipping...${NC}"
    fi
fi

echo ""
echo -ne "${YELLOW}Press Enter to exit...${NC}"
read