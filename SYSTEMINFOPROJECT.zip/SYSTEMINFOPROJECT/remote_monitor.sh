#!/bin/bash

# ==================== REMOTE MONITORING SCRIPT ====================
# NSCS Cybersecurity Project - Remote System Audit via SSH
# This script allows monitoring of remote Linux systems securely

# ==================== COLORS ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m'

# ==================== CONFIGURATION ====================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORT_DIR="${SCRIPT_DIR}/remote_reports"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
HOSTNAME=$(hostname)

# Create remote reports directory
mkdir -p "$REPORT_DIR"

# ==================== FUNCTIONS ====================

# Display banner
show_banner() {
    clear
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
    echo -e "${CYAN}${BOLD}║     ${YELLOW}NSCS - REMOTE SYSTEM MONITOR${CYAN}                               ║${NC}"
    echo -e "${CYAN}${BOLD}║     ${GREEN}Secure SSH-Based Remote Audit Tool${CYAN}                         ║${NC}"
    echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Show menu
show_menu() {
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                    REMOTE MONITORING MENU${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${GREEN}1${NC}) ${CYAN}Single Remote System Audit${NC}"
    echo -e "  ${GREEN}2${NC}) ${CYAN}Multiple Remote Systems Audit${NC}"
    echo -e "  ${GREEN}3${NC}) ${CYAN}View Previous Remote Reports${NC}"
    echo -e "  ${GREEN}4${NC}) ${CYAN}Setup SSH Key Authentication${NC}"
    echo -e "  ${GREEN}5${NC}) ${RED}Exit${NC}"
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# Test SSH connection
test_ssh_connection() {
    local user="$1"
    local host="$2"
    
    echo -e "${YELLOW}Testing connection to ${user}@${host}...${NC}"
    
    if ssh -o ConnectTimeout=5 -o BatchMode=yes "$user@$host" "echo 'OK'" 2>/dev/null | grep -q "OK"; then
        echo -e "${GREEN}✓ Connection successful!${NC}"
        return 0
    else
        echo -e "${RED}✗ Connection failed!${NC}"
        echo -e "${YELLOW}Please check:${NC}"
        echo "  - Host is reachable (ping $host)"
        echo "  - SSH service is running on remote host"
        echo "  - SSH key is configured (or password authentication is enabled)"
        return 1
    fi
}

# Run audit on single remote system
run_remote_audit() {
    local remote_user="$1"
    local remote_host="$2"
    local report_type="$3"
    local audit_scope="$4"
    
    echo ""
    echo -e "${BLUE}========================================================${NC}"
    echo -e "${BLUE}     Running Audit on: ${remote_user}@${remote_host}${NC}"
    echo -e "${BLUE}========================================================${NC}"
    echo ""
    
    # Create remote report file
    local remote_report="${REPORT_DIR}/remote_${remote_host}_${audit_scope}_${report_type}_${TIMESTAMP}.txt"
    
    # Check if audit script exists on remote system
    echo -e "${YELLOW}Checking if audit tool exists on remote system...${NC}"
    
    ssh "$remote_user@$remote_host" 'bash -s' << 'CHECK_EOF'
        if [ -f ~/SYSTEMINFOPROJECT/main.sh ]; then
            echo "EXISTS"
        else
            echo "NOT_EXISTS"
        fi
CHECK_EOF
    local check_result=$(ssh "$remote_user@$remote_host" 'test -f ~/SYSTEMINFOPROJECT/main.sh && echo "EXISTS" || echo "NOT_EXISTS"')
    
    if [ "$check_result" = "NOT_EXISTS" ]; then
        echo -e "${RED}✗ Audit tool not found on remote system!${NC}"
        echo -e "${YELLOW}Please install the audit tool on remote system first.${NC}"
        return 1
    fi
    
    echo -e "${GREEN}✓ Audit tool found${NC}"
    echo ""
    echo -e "${YELLOW}Running audit on remote system...${NC}"
    echo ""
    
    # Run the audit on remote system
    {
        echo "========================================================"
        echo "     REMOTE SYSTEM AUDIT REPORT"
        echo "========================================================"
        echo "Local Host (Monitoring from): $HOSTNAME"
        echo "Remote Host: $remote_host"
        echo "Remote User: $remote_user"
        echo "Report Date: $(date)"
        echo "Report Type: ${report_type^^}"
        echo "Audit Scope: ${audit_scope^^}"
        echo "========================================================"
        echo ""
        
        # Execute remote audit
        ssh "$remote_user@$remote_host" "cd ~/SYSTEMINFOPROJECT && ./main.sh $audit_scope $report_type"
        
        echo ""
        echo "========================================================"
        echo "End of Remote Audit Report"
        echo "========================================================"
        
    } | tee "$remote_report"
    
    echo ""
    echo -e "${GREEN}✓ Remote audit completed!${NC}"
    echo -e "${YELLOW}Report saved to: $remote_report${NC}"
    
    # Ask to send report via email
    echo ""
    echo -ne "${YELLOW}Send this report via email? (y/n): ${NC}"
    read send_email
    if [[ "$send_email" == "y" || "$send_email" == "Y" ]]; then
        echo -ne "${YELLOW}Enter email address: ${NC}"
        read email_addr
        if [[ -n "$email_addr" ]]; then
            mail -s "Remote Audit Report - $remote_host" "$email_addr" < "$remote_report" 2>/dev/null
            echo -e "${GREEN}✓ Report sent to $email_addr${NC}"
        fi
    fi
}

# Run audit on multiple remote systems
run_multiple_remote_audit() {
    local report_type="$1"
    local audit_scope="$2"
    
    echo ""
    echo -e "${YELLOW}Enter remote systems (one per line, empty line to finish):${NC}"
    echo -e "${CYAN}Format: username@hostname or username@ip_address${NC}"
    echo ""
    
    local systems=()
    while true; do
        echo -n "> "
        read entry
        if [ -z "$entry" ]; then
            break
        fi
        systems+=("$entry")
    done
    
    if [ ${#systems[@]} -eq 0 ]; then
        echo -e "${RED}No systems entered. Returning to menu.${NC}"
        return
    fi
    
    echo ""
    echo -e "${GREEN}Will audit ${#systems[@]} system(s)${NC}"
    echo ""
    
    # Create combined report
    local combined_report="${REPORT_DIR}/remote_multiple_${TIMESTAMP}.txt"
    
    {
        echo "========================================================"
        echo "     MULTIPLE REMOTE SYSTEMS AUDIT REPORT"
        echo "========================================================"
        echo "Monitoring Host: $HOSTNAME"
        echo "Report Date: $(date)"
        echo "Report Type: ${report_type^^}"
        echo "Audit Scope: ${audit_scope^^}"
        echo "Total Systems: ${#systems[@]}"
        echo "========================================================"
        echo ""
        
        for system in "${systems[@]}"; do
            remote_user=$(echo "$system" | cut -d'@' -f1)
            remote_host=$(echo "$system" | cut -d'@' -f2)
            
            echo ""
            echo "========================================================"
            echo "     SYSTEM: $remote_host"
            echo "========================================================"
            echo ""
            
            # Test connection first
            if ssh -o ConnectTimeout=5 -o BatchMode=yes "$remote_user@$remote_host" "echo 'OK'" 2>/dev/null | grep -q "OK"; then
                ssh "$remote_user@$remote_host" "cd ~/SYSTEMINFOPROJECT && ./main.sh $audit_scope $report_type" 2>/dev/null
            else
                echo -e "${RED}✗ Connection failed to $remote_host${NC}"
            fi
            
            echo ""
        done
        
        echo ""
        echo "========================================================"
        echo "End of Multiple Systems Report"
        echo "========================================================"
        
    } | tee "$combined_report"
    
    echo ""
    echo -e "${GREEN}✓ Combined report saved to: $combined_report${NC}"
}

# View previous remote reports
view_reports() {
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                  PREVIOUS REMOTE REPORTS${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [ ! -d "$REPORT_DIR" ] || [ -z "$(ls -A "$REPORT_DIR" 2>/dev/null)" ]; then
        echo -e "${RED}No remote reports found.${NC}"
        return
    fi
    
    echo "Available reports:"
    echo ""
    ls -lh "$REPORT_DIR"/remote_*.txt 2>/dev/null | nl
    
    echo ""
    echo -ne "${YELLOW}Enter report number to view (or 0 to cancel): ${NC}"
    read report_num
    
    if [ "$report_num" -gt 0 ] 2>/dev/null; then
        local report_file=$(ls -t "$REPORT_DIR"/remote_*.txt 2>/dev/null | sed -n "${report_num}p")
        if [ -f "$report_file" ]; then
            less "$report_file"
        else
            echo -e "${RED}Invalid selection${NC}"
        fi
    fi
}

# Setup SSH key authentication
setup_ssh_keys() {
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                SSH KEY AUTHENTICATION SETUP${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Check if SSH key already exists
    if [ ! -f ~/.ssh/id_rsa ]; then
        echo -e "${YELLOW}No SSH key found. Generating one...${NC}"
        ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa -N ""
        echo -e "${GREEN}✓ SSH key generated at ~/.ssh/id_rsa${NC}"
    else
        echo -e "${GREEN}✓ SSH key already exists at ~/.ssh/id_rsa${NC}"
    fi
    
    echo ""
    echo -e "${YELLOW}Enter remote system details to copy SSH key:${NC}"
    echo -ne "${CYAN}Username: ${NC}"
    read remote_user
    echo -ne "${CYAN}Hostname/IP: ${NC}"
    read remote_host
    
    echo ""
    echo -e "${YELLOW}Copying SSH key to ${remote_user}@${remote_host}...${NC}"
    echo -e "${YELLOW}Enter password when prompted:${NC}"
    
    ssh-copy-id "$remote_user@$remote_host"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ SSH key successfully copied!${NC}"
        echo -e "${GREEN}✓ You can now connect without password${NC}"
        
        # Test the connection
        echo ""
        ssh -o BatchMode=yes "$remote_user@$remote_host" "echo 'Connection successful!'"
    else
        echo -e "${RED}✗ Failed to copy SSH key${NC}"
    fi
}

# ==================== MAIN ====================
main() {
    # Check if running in interactive mode
    if [ $# -eq 0 ]; then
        # Interactive mode with menu
        while true; do
            show_banner
            show_menu
            echo -ne "${YELLOW}${BOLD}Enter your choice [1-5]: ${NC}"
            read choice
            echo ""
            
            case $choice in
                1)
                    # Single remote system
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo -e "${YELLOW}${BOLD}                  SINGLE REMOTE SYSTEM AUDIT${NC}"
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo ""
                    echo -ne "${YELLOW}Remote username: ${NC}"
                    read remote_user
                    echo -ne "${YELLOW}Remote hostname/IP: ${NC}"
                    read remote_host
                    
                    # Test connection
                    if ! test_ssh_connection "$remote_user" "$remote_host"; then
                        echo ""
                        echo -ne "${YELLOW}Press Enter to continue...${NC}"
                        read
                        continue
                    fi
                    
                    echo ""
                    echo -e "${YELLOW}Select report type:${NC}"
                    echo "  1) Short Report"
                    echo "  2) Full Report"
                    echo -n "Choice [1-2]: "
                    read report_choice
                    report_type="short"
                    [ "$report_choice" = "2" ] && report_type="full"
                    
                    echo ""
                    echo -e "${YELLOW}Select audit scope:${NC}"
                    echo "  1) Hardware Only"
                    echo "  2) Software Only"
                    echo "  3) Both"
                    echo -n "Choice [1-3]: "
                    read scope_choice
                    case $scope_choice in
                        1) audit_scope="hardware" ;;
                        2) audit_scope="software" ;;
                        3) audit_scope="both" ;;
                        *) audit_scope="both" ;;
                    esac
                    
                    run_remote_audit "$remote_user" "$remote_host" "$report_type" "$audit_scope"
                    ;;
                    
                2)
                    # Multiple remote systems
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo -e "${YELLOW}${BOLD}                  MULTIPLE SYSTEMS AUDIT${NC}"
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo ""
                    
                    echo -e "${YELLOW}Select report type:${NC}"
                    echo "  1) Short Report"
                    echo "  2) Full Report"
                    echo -n "Choice [1-2]: "
                    read report_choice
                    report_type="short"
                    [ "$report_choice" = "2" ] && report_type="full"
                    
                    echo ""
                    echo -e "${YELLOW}Select audit scope:${NC}"
                    echo "  1) Hardware Only"
                    echo "  2) Software Only"
                    echo "  3) Both"
                    echo -n "Choice [1-3]: "
                    read scope_choice
                    case $scope_choice in
                        1) audit_scope="hardware" ;;
                        2) audit_scope="software" ;;
                        3) audit_scope="both" ;;
                        *) audit_scope="both" ;;
                    esac
                    
                    run_multiple_remote_audit "$report_type" "$audit_scope"
                    ;;
                    
                3)
                    view_reports
                    ;;
                    
                4)
                    setup_ssh_keys
                    ;;
                    
                5)
                    echo -e "${GREEN}Goodbye!${NC}"
                    exit 0
                    ;;
                    
                *)
                    echo -e "${RED}Invalid choice. Please enter 1-5${NC}"
                    ;;
            esac
            
            echo ""
            echo -ne "${YELLOW}Press Enter to continue...${NC}"
            read
        done
    else
        # Command line mode
        # Usage: ./remote_monitor.sh user@host [short|full] [hardware|software|both]
        
        if [ $# -lt 1 ]; then
            echo "Usage: $0 [user@host] [short|full] [hardware|software|both]"
            echo ""
            echo "Examples:"
            echo "  $0                                      # Interactive menu"
            echo "  $0 admin@192.168.1.100                 # Quick audit with defaults"
            echo "  $0 admin@192.168.1.100 short hardware  # Hardware only, short report"
            echo "  $0 admin@192.168.1.100 full both       # Full audit on remote system"
            exit 1
        fi
        
        # Parse command line arguments
        remote_target="$1"
        remote_user=$(echo "$remote_target" | cut -d'@' -f1)
        remote_host=$(echo "$remote_target" | cut -d'@' -f2)
        
        report_type="${2:-short}"
        audit_scope="${3:-both}"
        
        run_remote_audit "$remote_user" "$remote_host" "$report_type" "$audit_scope"
    fi
}

# Run main function
main "$@"
