#!/bin/bash

# Directory for reports
REPORT_DIR="/home/amirimaria/SYSTEMINFOPROJECT/reports"
mkdir -p "$REPORT_DIR"

# Generate timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
REPORT_FILE="${REPORT_DIR}/cron_audit_${TIMESTAMP}.txt"

# Run the audit with arguments to bypass menu
cd /home/amirimaria/SYSTEMINFOPROJECT

# Force run with both and full without any menu
{
    echo "both" | ./main.sh full
} > "$REPORT_FILE" 2>&1

echo "$(date): Report saved to $REPORT_FILE" >> "${REPORT_DIR}/cron.log"
