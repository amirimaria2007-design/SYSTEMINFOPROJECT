#!/bin/bash

# ==================== COMPARE REPORTS SCRIPT ====================
# NSCS Cybersecurity Project - Report Comparison Tool
# This script compares two audit reports and shows differences

# ==================== COLORS ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m'

# ==================== CONFIGURATION ====================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORT_DIR="/var/log/sys_audit"
LOCAL_REPORT_DIR="${SCRIPT_DIR}/reports"
REMOTE_REPORT_DIR="${SCRIPT_DIR}/remote_reports"

# Find all possible report locations
REPORT_LOCATIONS=(
    "$REPORT_DIR"
    "$LOCAL_REPORT_DIR"
    "$REMOTE_REPORT_DIR"
)

# ==================== FUNCTIONS ====================

# Display banner
show_banner() {
    clear
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
    echo -e "${CYAN}${BOLD}║     ${YELLOW}NSCS - REPORT COMPARISON TOOL${CYAN}                                 ║${NC}"
    echo -e "${CYAN}${BOLD}║     ${GREEN}Detect Changes Between Audit Reports${CYAN}                           ║${NC}"
    echo -e "${CYAN}${BOLD}║                                                              ║${NC}"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Show main menu
show_menu() {
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                    REPORT COMPARISON MENU${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "  ${GREEN}1${NC}) ${CYAN}Compare Two Reports${NC}"
    echo -e "  ${GREEN}2${NC}) ${CYAN}Compare Latest vs Previous Report${NC}"
    echo -e "  ${GREEN}3${NC}) ${CYAN}Compare Today vs Yesterday Report${NC}"
    echo -e "  ${GREEN}4${NC}) ${CYAN}Generate Change Summary${NC}"
    echo -e "  ${GREEN}5${NC}) ${CYAN}List All Available Reports${NC}"
    echo -e "  ${GREEN}6${NC}) ${RED}Exit${NC}"
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# Find all reports from all locations
find_all_reports() {
    local reports=()
    for location in "${REPORT_LOCATIONS[@]}"; do
        if [ -d "$location" ]; then
            while IFS= read -r file; do
                if [ -f "$file" ]; then
                    reports+=("$file")
                fi
            done < <(find "$location" -maxdepth 1 -name "*.txt" 2>/dev/null | grep -E "audit_|remote_")
        fi
    done
    printf '%s\n' "${reports[@]}" | sort -r
}

# Display available reports
list_reports() {
    local reports=($(find_all_reports))
    
    if [ ${#reports[@]} -eq 0 ]; then
        echo -e "${RED}No reports found!${NC}"
        echo -e "${YELLOW}Please run an audit first: ./main.sh both short${NC}"
        return 1
    fi
    
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                  AVAILABLE REPORTS${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    printf "  ${GREEN}%-4s${NC} ${CYAN}%-50s${NC} ${YELLOW}%s${NC}\n" "No." "Filename" "Date"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────────${NC}"
    
    local count=1
    for report in "${reports[@]}"; do
        local filename=$(basename "$report")
        local filedate=$(stat -c %y "$report" 2>/dev/null | cut -d' ' -f1)
        printf "  ${GREEN}%-4d${NC} ${CYAN}%-50s${NC} ${YELLOW}%s${NC}\n" "$count" "$filename" "$filedate"
        ((count++))
    done
    echo ""
    
    return 0
}

# Select a report by number
select_report() {
    local prompt="$1"
    local reports=($(find_all_reports))
    
    if [ ${#reports[@]} -eq 0 ]; then
        return 1
    fi
    
    list_reports
    echo -ne "${YELLOW}$prompt [1-${#reports[@]}]: ${NC}"
    read num
    
    if [[ "$num" =~ ^[0-9]+$ ]] && [ "$num" -ge 1 ] && [ "$num" -le ${#reports[@]} ]; then
        echo "${reports[$((num-1))]}"
        return 0
    else
        echo -e "${RED}Invalid selection!${NC}"
        return 1
    fi
}

# Compare two reports
compare_reports() {
    local report1="$1"
    local report2="$2"
    
    if [ ! -f "$report1" ]; then
        echo -e "${RED}Report 1 not found: $report1${NC}"
        return 1
    fi
    
    if [ ! -f "$report2" ]; then
        echo -e "${RED}Report 2 not found: $report2${NC}"
        return 1
    fi
    
    echo ""
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}${BOLD}                    COMPARISON RESULTS${NC}"
    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${GREEN}Report 1 (Older):${NC} $(basename "$report1")"
    echo -e "${GREEN}Report 2 (Newer):${NC} $(basename "$report2")"
    echo ""
    
    # Check if files are identical
    if cmp -s "$report1" "$report2"; then
        echo -e "${GREEN}✓ Reports are IDENTICAL - No changes detected${NC}"
        return 0
    fi
    
    echo -e "${YELLOW}⚠ Reports are DIFFERENT - Changes detected:${NC}"
    echo ""
    
    # Show line count difference
    local lines1=$(wc -l < "$report1")
    local lines2=$(wc -l < "$report2")
    local line_diff=$((lines2 - lines1))
    
    echo -e "${BLUE}📊 Statistics:${NC}"
    echo -e "  Report 1 lines: $lines1"
    echo -e "  Report 2 lines: $lines2"
    if [ $line_diff -gt 0 ]; then
        echo -e "  ${GREEN}+$line_diff lines added${NC}"
    elif [ $line_diff -lt 0 ]; then
        echo -e "  ${RED}$line_diff lines removed${NC}"
    fi
    echo ""
    
    # Show summary of differences
    echo -e "${BLUE}📝 Summary of Differences:${NC}"
    echo -e "${CYAN}────────────────────────────────────────────────────────────────────${NC}"
    
    # Show added lines
    local added=$(diff -u "$report1" "$report2" | grep -E "^\+" | grep -v "^+++" | head -10)
    if [ -n "$added" ]; then
        echo -e "${GREEN}Added lines (first 10):${NC}"
        echo "$added" | head -10
        echo ""
    fi
    
    # Show removed lines
    local removed=$(diff -u "$report1" "$report2" | grep -E "^\-" | grep -v "^---" | head -10)
    if [ -n "$removed" ]; then
        echo -e "${RED}Removed lines (first 10):${NC}"
        echo "$removed" | head -10
        echo ""
    fi
    
    # Show context
    echo -e "${BLUE}📄 Context (surrounding lines):${NC}"
    diff -u "$report1" "$report2" | head -40
    
    echo ""
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}For full comparison, run:${NC}"
    echo -e "  diff -u \"$report1\" \"$report2\" | less"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    
    # Generate change report
    local change_report="${SCRIPT_DIR}/reports/change_summary_$(date +%Y%m%d_%H%M%S).txt"
    {
        echo "========================================================"
        echo "     CHANGE DETECTION REPORT"
        echo "========================================================"
        echo "Generated: $(date)"
        echo "Report 1: $(basename "$report1")"
        echo "Report 2: $(basename "$report2")"
        echo "========================================================"
        echo ""
        echo "Line count difference: $line_diff"
        echo ""
        echo "=== Full Difference ==="
        diff -u "$report1" "$report2"
    } > "$change_report"
    
    echo ""
    echo -e "${GREEN}✓ Change report saved to: $change_report${NC}"
}

# Compare latest vs previous report
compare_latest_previous() {
    local reports=($(find_all_reports))
    
    if [ ${#reports[@]} -lt 2 ]; then
        echo -e "${RED}Need at least 2 reports to compare!${NC}"
        return 1
    fi
    
    local latest="${reports[0]}"
    local previous="${reports[1]}"
    
    echo ""
    echo -e "${YELLOW}Comparing Latest vs Previous Report...${NC}"
    echo -e "  Latest:  $(basename "$latest")"
    echo -e "  Previous: $(basename "$previous")"
    
    compare_reports "$previous" "$latest"
}

# Compare today vs yesterday report
compare_today_yesterday() {
    local today=$(date +%Y%m%d)
    local yesterday=$(date -d "yesterday" +%Y%m%d 2>/dev/null || date -v-1d +%Y%m%d 2>/dev/null)
    
    local today_report=""
    local yesterday_report=""
    
    for report in $(find_all_reports); do
        if [[ "$report" =~ $today ]]; then
            today_report="$report"
        fi
        if [[ "$report" =~ $yesterday ]]; then
            yesterday_report="$report"
        fi
    done
    
    if [ -z "$today_report" ]; then
        echo -e "${RED}No report found for today ($today)${NC}"
        return 1
    fi
    
    if [ -z "$yesterday_report" ]; then
        echo -e "${RED}No report found for yesterday ($yesterday)${NC}"
        return 1
    fi
    
    echo ""
    echo -e "${YELLOW}Comparing Today vs Yesterday...${NC}"
    compare_reports "$yesterday_report" "$today_report"
}

# Generate change summary
generate_change_summary() {
    local reports=($(find_all_reports))
    
    if [ ${#reports[@]} -lt 2 ]; then
        echo -e "${RED}Need at least 2 reports to generate summary!${NC}"
        return 1
    fi
    
    local summary_file="${SCRIPT_DIR}/reports/changes_$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "========================================================"
        echo "     SYSTEM CHANGE SUMMARY REPORT"
        echo "========================================================"
        echo "Generated: $(date)"
        echo "Hostname: $(hostname)"
        echo "Total Reports Available: ${#reports[@]}"
        echo "========================================================"
        echo ""
        
        echo "=== Report Timeline ==="
        local count=1
        for report in "${reports[@]}"; do
            local filename=$(basename "$report")
            local filedate=$(stat -c "%y" "$report" 2>/dev/null | cut -d'.' -f1)
            local filesize=$(du -h "$report" 2>/dev/null | cut -f1)
            echo "  $count. $filename - $filedate ($filesize)"
            ((count++))
        done
        
        echo ""
        echo "=== Changes Between Consecutive Reports ==="
        
        for i in $(seq 1 $((${#reports[@]} - 1))); do
            local older="${reports[$i]}"
            local newer="${reports[$((i-1))]}"
            
            echo ""
            echo "--- Between: $(basename "$older") → $(basename "$newer") ---"
            
            local diff_count=$(diff -u "$older" "$newer" | grep -E "^\+|^-" | grep -v "^+++\|^---" | wc -l)
            local added=$(diff -u "$older" "$newer" | grep -c "^+" | grep -v "^+++")
            local removed=$(diff -u "$older" "$newer" | grep -c "^-" | grep -v "^---")
            
            echo "  Total changes: $diff_count lines"
            echo "  Added: $added lines"
            echo "  Removed: $removed lines"
        done
        
        echo ""
        echo "========================================================"
        echo "End of Change Summary"
        echo "========================================================"
        
    } > "$summary_file"
    
    echo ""
    echo -e "${GREEN}✓ Change summary saved to: $summary_file${NC}"
    echo ""
    echo -e "${YELLOW}Preview:${NC}"
    head -20 "$summary_file"
}

# ==================== MAIN ====================
main() {
    # Check if command line arguments provided
    if [ $# -eq 2 ]; then
        # Direct comparison mode: ./compare_reports.sh report1.txt report2.txt
        compare_reports "$1" "$2"
    elif [ $# -eq 1 ] && [ "$1" = "--latest" ]; then
        # Compare latest vs previous
        compare_latest_previous
    elif [ $# -eq 1 ] && [ "$1" = "--today" ]; then
        # Compare today vs yesterday
        compare_today_yesterday
    else
        # Interactive menu mode
        while true; do
            show_banner
            show_menu
            echo -ne "${YELLOW}${BOLD}Enter your choice [1-6]: ${NC}"
            read choice
            echo ""
            
            case $choice in
                1)
                    # Compare two reports
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo -e "${YELLOW}${BOLD}                  COMPARE TWO REPORTS${NC}"
                    echo -e "${CYAN}${BOLD}════════════════════════════════════════════════════════════════${NC}"
                    echo ""
                    
                    report1=$(select_report "Select first report (older)")
                    if [ -n "$report1" ]; then
                        report2=$(select_report "Select second report (newer)")
                        if [ -n "$report2" ]; then
                            compare_reports "$report1" "$report2"
                        fi
                    fi
                    ;;
                    
                2)
                    # Compare latest vs previous
                    compare_latest_previous
                    ;;
                    
                3)
                    # Compare today vs yesterday
                    compare_today_yesterday
                    ;;
                    
                4)
                    # Generate change summary
                    generate_change_summary
                    ;;
                    
                5)
                    # List all reports
                    list_reports
                    ;;
                    
                6)
                    echo -e "${GREEN}Goodbye!${NC}"
                    exit 0
                    ;;
                    
                *)
                    echo -e "${RED}Invalid choice. Please enter 1-6${NC}"
                    ;;
            esac
            
            echo ""
            echo -ne "${YELLOW}Press Enter to continue...${NC}"
            read
        done
    fi
}

# Run main function
main "$@"
