#!/bin/bash
# reporting/utils.sh - Shared utility functions for reporting

# Function to sanitize text (remove special chars)
sanitize_text() {
    echo "$1" | sed 's/[^a-zA-Z0-9 .,_-]//g'
}

# Function to truncate long text
truncate_text() {
    local text="$1"
    local max_length="${2:-50}"
    
    if [ ${#text} -gt $max_length ]; then
        echo "${text:0:$max_length}..."
    else
        echo "$text"
    fi
}

# Function to convert to uppercase
to_upper() {
    echo "$1" | tr '[:lower:]' '[:upper:]'
}

# Function to convert to lowercase
to_lower() {
    echo "$1" | tr '[:upper:]' '[:lower:]'
}

# Function to get current timestamp in different formats
get_timestamp() {
    local format="${1:-default}"
    
    case "$format" in
        "filename")
            date +"%Y%m%d_%H%M%S"
            ;;
        "readable")
            date +"%Y-%m-%d %H:%M:%S"
            ;;
        "iso")
            date -Iseconds
            ;;
        *)
            date
            ;;
    esac
}

